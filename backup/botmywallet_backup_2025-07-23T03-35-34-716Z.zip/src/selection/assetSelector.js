import { getClosingPrices } from '../data/priceHistory.js'
import { getTradingDecision } from '../strategy/fearAwareEmaReversal.js'

// ✅ Lista actualizada con nuevos activos identificados
const pairsToCheck = [
  'BTCUSDT',
  'ETHUSDT',
  'BNBUSDT',
  'SOLUSDT',
  'OMNIUSDT',
  'CUSDT',       // Si CHAINBASE está disponible con este símbolo
  'REZUSDT',
  'DOGEUSDT'
]

/**
 * Evalúa múltiples pares y selecciona el primero que tenga señal válida.
 * @returns {{symbol:string, decision:string}|null}
 */
export async function selectBestAsset() {
  for (const symbol of pairsToCheck) {
    try {
      const prices = await getClosingPrices(symbol, '1h', 100)
      if (!prices.length) continue

      const decision = await getTradingDecision(prices)
      console.log(`🔍 ${symbol} → ${decision}`)

      if (decision === 'BUY' || decision === 'SELL') {
        return { symbol, decision }
      }
    } catch (err) {
      console.warn(`⚠️ No se pudo analizar ${symbol}: ${err.message}`)
      continue
    }
  }

  console.log('📉 Ningún activo con señal fuerte en este ciclo.')
  return null
}
