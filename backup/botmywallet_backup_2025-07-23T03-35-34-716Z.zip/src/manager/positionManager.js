import fs from 'fs'
import path from 'path'
import { client } from '../utils/binanceClient.js'
import { logEntry } from '../utils/logger.js'

/**
 * Monitorea las posiciones abiertas y ejecuta cierres si toca SL/TP
 */
export async function monitorPositions() {
  const filePath = path.resolve('data/history.json')
  if (!fs.existsSync(filePath)) return logEntry('⚠️ No hay historial para monitorear')

  const raw = fs.readFileSync(filePath, 'utf8')
  const history = JSON.parse(raw)

  const openTrades = history.filter(op => !op.closed && op.type === 'MARKET')

  for (const trade of openTrades) {
    const { symbol, side, entry, sl, tp } = trade
    try {
      const ticker = await client.prices({ symbol })
      const current = parseFloat(ticker[symbol])
      const exitSide = side === 'BUY' ? 'SELL' : 'BUY'

      const slHit = side === 'BUY' ? current <= sl : current >= sl
      const tpHit = side === 'BUY' ? current >= tp : current <= tp

      if (slHit || tpHit) {
        const reason = slHit ? 'Stop Loss' : 'Take Profit'

        const closeOrder = await client.order({
          symbol,
          side: exitSide,
          type: 'MARKET',
          quantity: trade.quantity
        })

        trade.closed = true
        trade.exitPrice = parseFloat(closeOrder.fills?.[0]?.price || closeOrder.price)
        trade.exitReason = reason
        trade.exitTimestamp = new Date().toISOString()

        logEntry(`✂️ ${symbol} cerrado por ${reason} a ${trade.exitPrice}`)
      }
    } catch (err) {
      logEntry(`❌ Error al vigilar ${symbol}: ${err.message}`)
    }
  }

  const updated = history.some(t => t.closed)
  if (updated) {
    fs.writeFileSync(filePath, JSON.stringify(history, null, 2))
    logEntry(`📋 Historial actualizado con ${history.filter(t => t.closed).length} cierres`)
  }
}
