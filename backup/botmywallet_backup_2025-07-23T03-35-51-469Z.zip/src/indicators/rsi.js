import { RSI } from 'technicalindicators'

/**
 * Calcula el índice de fuerza relativa (RSI).
 * @param {number[]} prices - Lista de precios (closing prices).
 * @param {number} period - Periodo para RSI (por defecto 14).
 * @returns {number|null} Último valor de RSI o null si no hay datos suficientes.
 */
export function calculateRsi(prices, period = 14) {
  if (!Array.isArray(prices) || prices.length < period + 1) {
    console.warn('⚠️ Datos insuficientes para RSI.')
    return null
  }
  const values = RSI.calculate({ values: prices, period })
  return values[values.length - 1]
}
