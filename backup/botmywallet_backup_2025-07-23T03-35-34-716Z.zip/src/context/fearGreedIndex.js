/**
 * Simula lectura del Fear & Greed Index desde una fuente externa
 * @returns {object} Niveles y tendencia del índice
 */
export function getFearGreedIndex() {
  // En versión real, esto podría venir de una API
  return {
    value: 52,         // Neutral (escala de 0 a 100)
    classification: 'Neutral',
    trend: 'Stable'    // Stable, Rising, Falling
  }
}
