import { client } from '../utils/binanceClient.js'
import { logEntry } from '../utils/logger.js'

/**
 * Obtiene precios de cierre para un símbolo y periodo específico
 * @param {string} symbol - Ej: 'BTCUSDT'
 * @param {string} interval - Ej: '1h', '15m', '1d'
 * @param {number} limit - Cantidad de velas a consultar (máx 1000)
 * @returns {Promise<number[]>} - Array de precios de cierre
 */
export async function getClosingPrices(symbol, interval = '1h', limit = 100) {
  try {
    const klines = await client.candles({ symbol, interval, limit })
    const closingPrices = klines.map(k => parseFloat(k.close))
    logEntry(`📊 ${symbol} | ${closingPrices.length} precios de cierre extraídos`)
    return closingPrices
  } catch (err) {
    logEntry(`❌ Error al obtener precios para ${symbol}: ${err.message}`)
    return []
  }
}