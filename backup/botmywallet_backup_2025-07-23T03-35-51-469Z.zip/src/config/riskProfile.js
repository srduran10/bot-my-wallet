export const riskProfiles = {
  conservador: {
    slPercent: 5,
    tpPercent: 2,
    validationDepth: 'strict',
    maxTradesPerDay: 1
  },
  moderado: {
    slPercent: 3,
    tpPercent: 5,
    validationDepth: 'balanced',
    maxTradesPerDay: 3
  },
  agresivo: {
    slPercent: 1.5,
    tpPercent: 8,
    validationDepth: 'flexible',
    maxTradesPerDay: 10
  }
}

// Perfil activo
export const activeProfile = 'moderado'
