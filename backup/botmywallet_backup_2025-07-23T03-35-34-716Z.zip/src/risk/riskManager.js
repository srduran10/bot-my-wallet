/**
 * Calcula niveles de Stop Loss y Take Profit.
 * @param {number} entryPrice - Precio de entrada.
 * @param {'BUY'|'SELL'} side - Dirección de la operación.
 * @param {number} slPercent - % Stop Loss (ej. 2 para 2%)
 * @param {number} tpPercent - % Take Profit (ej. 3 para 3%)
 * @returns {{stopLoss:number, takeProfit:number}} Niveles calculados.
 */
export function calculateRiskLevels(entryPrice, side, slPercent = 2, tpPercent = 3) {
  const slOffset = entryPrice * (slPercent / 100)
  const tpOffset = entryPrice * (tpPercent / 100)

  let stopLoss, takeProfit

  if (side === 'BUY') {
    stopLoss = entryPrice - slOffset
    takeProfit = entryPrice + tpOffset
  } else if (side === 'SELL') {
    stopLoss = entryPrice + slOffset
    takeProfit = entryPrice - tpOffset
  } else {
    throw new Error('❌ Dirección inválida. Usa BUY o SELL.')
  }

  return { stopLoss, takeProfit }
}
