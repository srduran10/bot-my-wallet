import { getFearGreedIndex } from '../context/fearGreedIndex.js'
import { detectEmaCross } from '../indicators/emaCross.js'
import { calculateRsi } from '../indicators/rsi.js'
import { calculateMacd } from '../indicators/macd.js'
import { tuneStrategy } from './strategyTuner.js'

export async function getTradingDecision(prices) {
  const config = tuneStrategy() || {}

  const emaSignal = config.ema?.penalize ? null : detectEmaCross(prices)
  const sentiment = config.sentiment?.penalize ? null : await getFearGreedIndex()
  const rsi = config.rsi?.penalize ? null : calculateRsi(prices)
  const macdObj = config.macd?.penalize ? null : calculateMacd(prices)

  console.log(`🔄 Señales ajustadas → EMA:${emaSignal}, Sentimiento:${sentiment}, RSI:${rsi}, MACD:${macdObj?.histogram}`)

  if ([emaSignal, sentiment, rsi, macdObj].some(val => val === null)) return 'HOLD'

  const buyCond =
    emaSignal === 'BUY' &&
    sentiment < 30 &&
    rsi < 30 &&
    macdObj.macd > macdObj.signal

  const sellCond =
    emaSignal === 'SELL' &&
    sentiment > 70 &&
    rsi > 70 &&
    macdObj.macd < macdObj.signal

  if (buyCond) return 'BUY'
  if (sellCond) return 'SELL'
  return 'HOLD'
}
