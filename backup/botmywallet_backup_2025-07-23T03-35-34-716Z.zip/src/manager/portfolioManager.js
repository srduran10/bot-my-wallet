import { client } from '../utils/binanceClient.js'
import { botConfig } from '../../runtime/config.js'
import { riskProfiles, activeProfile } from '../config/riskProfile.js'
import { getClosingPrices } from '../data/priceHistory.js'
import { getTradingDecision } from '../strategy/fearAwareEmaReversal.js'
import { logEntry } from '../utils/logger.js'

// Activos válidos en Binance Testnet (confirmados)
const symbols = [
  'BTCUSDT',
  'ETHUSDT',
  'BNBUSDT',
  'LTCUSDT',
  'XRPUSDT',
  'BCHUSDT',
  'EOSUSDT',
  'DOGEUSDT'
]

/**
 * Escanea todos los activos y obtiene señal + precio de entrada
 */
async function scanAllAssets(strategyConfig) {
  const results = []

  for (const symbol of symbols) {
    try {
      const prices = await getClosingPrices(symbol, '1h', 100)
      if (prices.length < 60) continue

      const decision = await getTradingDecision(prices, strategyConfig)
      const entryPrice = prices[prices.length - 1]

      if (decision === 'BUY' || decision === 'SELL') {
        results.push({ symbol, decision, entryPrice })
      }
    } catch (err) {
      logEntry(`❌ Falló escaneo en ${symbol}: ${err.message}`)
      continue
    }
  }

  return results
}

/**
 * Define el portafolio para ejecutar en este ciclo
 * @returns {Promise<Array<{ symbol, decision, quantity }>>}
 */
export async function definePortfolio(strategyConfig) {
  const profile = riskProfiles[activeProfile]
  const maxPositions = botConfig.maxActiveTrades || profile.maxTradesPerDay

  try {
    const account = await client.accountInfo()
    const usdtBalance = parseFloat(
      account.balances.find(b => b.asset === 'USDT')?.free || 0
    )

    if (usdtBalance <= 0) {
      logEntry('⚠️ Sin saldo USDT disponible')
      return []
    }

    const signals = await scanAllAssets(strategyConfig)
    if (!signals.length) {
      logEntry('📉 No hay señales válidas en ningún activo')
      return []
    }

    const buys = signals.filter(s => s.decision === 'BUY')
    const selected = buys.slice(0, maxPositions)

    const allocationPerPos = usdtBalance / selected.length
    const portfolio = selected.map(({ symbol, decision, entryPrice }) => {
      const qty = (allocationPerPos / entryPrice).toFixed(6)
      return { symbol, decision, quantity: parseFloat(qty) }
    })

    logEntry(
      `📋 Portafolio definido: ${portfolio
        .map(p => `${p.symbol} (${p.quantity})`)
        .join(', ')}`
    )

    return portfolio
  } catch (err) {
    logEntry(`❌ Error al definir portafolio: ${err.message}`)
    return []
  }
}
