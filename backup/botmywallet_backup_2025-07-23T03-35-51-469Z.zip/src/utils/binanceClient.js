import pkg from 'binance-api-node'
const binance = pkg.default || pkg

export const client = binance({
  apiKey: process.env.BINANCE_API_KEY,
  apiSecret: process.env.BINANCE_API_SECRET,
  httpBase: process.env.BINANCE_API_URL,
  wsBase:  process.env.BINANCE_API_URL.replace(/^http/, 'ws')
})
