import { MACD } from 'technicalindicators'

/**
 * Calcula la MACD y su señal.
 * @param {number[]} prices - Lista de precios (closing prices).
 * @param {object} params - Configuración de periodos.
 * @param {number} params.fastPeriod - Periodo rápido (por defecto 12).
 * @param {number} params.slowPeriod - Periodo lento (por defecto 26).
 * @param {number} params.signalPeriod - Periodo de señal (por defecto 9).
 * @returns {{macd:number, signal:number, histogram:number}|null}
 */
export function calculateMacd(
  prices,
  { fastPeriod = 12, slowPeriod = 26, signalPeriod = 9 } = {}
) {
  if (!Array.isArray(prices) || prices.length < slowPeriod + signalPeriod) {
    console.warn('⚠️ Datos insuficientes para MACD.')
    return null
  }

  const result = MACD.calculate({
    values: prices,
    fastPeriod,
    slowPeriod,
    signalPeriod,
    SimpleMAOscillator: false,
    SimpleMASignal: false
  })

  // Devuelve el último objeto { macd, signal, histogram }
  return result[result.length - 1]
}
